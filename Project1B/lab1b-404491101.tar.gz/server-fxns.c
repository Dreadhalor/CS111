int create_server_socket(int port) {
  int socket_fd;
  struct sockaddr_in server_address;
  prepare_socket_vals(port, &socket_fd, &server_address);
	if (socket_fd < 0) return -1;

  bind(socket_fd, (struct sockaddr *) &server_address, sizeof(server_address));
  listen(socket_fd, 5);

  return socket_fd;
}

void poll_client(struct pollfd src){
  if (src.revents & POLLIN) {
    char buffer[BUFFER_SIZE];
    int len = read(src.fd, &buffer, sizeof(buffer));
    for (int i = 0; i < len; i++) {
      switch (buffer[i]) {
        case '\003':
          raise(SIGINT);
          break;
        default: {
          write(STDOUT_FILENO, buffer + i, 1);
          //write(src.fd, buffer + i, 1);
        }
      }
    }
  }
}
void poll_shell(){
  
}