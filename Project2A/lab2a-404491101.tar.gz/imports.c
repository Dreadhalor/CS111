#ifndef IMPORTS
#define IMPORTS
  #include <getopt.h>
  #include <stdio.h>
  #include <stdlib.h>
  #include <pthread.h>
  #include <time.h>
  #include <math.h>
  #include <string.h>
#endif